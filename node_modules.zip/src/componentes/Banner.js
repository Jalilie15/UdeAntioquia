import "./Banner.css";

const Banner = () => {
  return (
    <div className="banner">
      <div className="banner-container"> 
        <h1>Tienda de Pokemon</h1>
        <p> Los Mejores precios de la Web</p>

      </div>
      
      
      
      </div>
  );
};
export default Banner;