function Admin() {
    return (
      <>
        <h1> Este es mi Administrador</h1>
      </>
    );
  }
  export default Admin;