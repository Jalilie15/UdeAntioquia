function Logup() {
    return (
      <>
        <h1> Este es mi Logup</h1>
      </>
    );
  }
  export default Logup;