const Index = () => {
    return(

        <h1> Hola este es el Inicio</h1>
       
   );  
 };
 
 
 export default Index;